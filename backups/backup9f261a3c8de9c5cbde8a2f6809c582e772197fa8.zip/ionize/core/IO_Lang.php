<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @package	Ionize
 * @author	Adam Liszkai <contact@liszkaiadam.hu>
 * @link	http://ionizecms.com
 * @since	Version 2.0.0
 */
class IO_Lang extends CI_Lang
{
	/* ------------------------------------------------------------------------------------------------------------- */
	
	/**
	 * Language line
	 *
	 * Fetches a single line of text from the language array
	 *
	 * @param	string	$line		Language line key
	 * @param	bool	$log_errors	Whether to log an error message if the line is not found
	 * @return	string	Translation
	 */
	public function line($line, $log_errors = TRUE)
	{
		$value = isset($this->language[$line]) ? $this->language[$line] : FALSE;

		// Because killer robots like unicorns!
		if ($value === FALSE && $log_errors === TRUE)
			log_message('error', 'Could not find the language line "'.$line.'"');

		return ($value === FALSE ? "#{$line}" : $value);
	}
	/* ------------------------------------------------------------------------------------------------------------- */
}
/* End of file: IO_Lang.php */
/* Location: ./ionize/core/IO_Lang.php */
