<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @package	Ionize
 * @author	Adam Liszkai <contact@liszkaiadam.hu>
 * @link	http://ionizecms.com
 * @since	Version 2.0.0
 */
class Migration_Structure extends CI_Migration
{
	/**
	 * Ionize version
	 *
	 */
	public final $version = '2.0.0';
	
	/* ------------------------------------------------------------------------------------------------------------- */

	public function up()
	{
		
	}
	/* ------------------------------------------------------------------------------------------------------------- */
	
	public function down()
	{
		
	}
	/* ------------------------------------------------------------------------------------------------------------- */
}

/* End of file: 200_Structure.php */
/* Location: ./ionize/migrations/200_Structure.php */
