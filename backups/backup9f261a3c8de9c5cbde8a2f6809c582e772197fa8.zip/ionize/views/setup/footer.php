		</section>
		
		<footer id="installer_footer">
			<div class="copyright">
				Copyright &copy; Ionize
			</div>
			<div class="benchmark">
				<span class="elapsed_time"><?=$elapsed_time?></span>
				<span class="memory_usage"><?=$memory_usage?></span>
			</div>
		</footer>
	</section>
</body>
