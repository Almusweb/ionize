<h2> <?=lang('wellcome_to_installer')?> </h2>

<p><?=lang('ionize_presentation')?></p>

<p><?=lang('more_information')?></p>

<h2><?=lang('lets_start')?></h2>

<?=anchor('setup/checkconfig', lang('next_step'), 'class="next_step"')?>
