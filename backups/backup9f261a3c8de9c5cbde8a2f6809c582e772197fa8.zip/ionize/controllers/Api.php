<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @package	Ionize
 * @author	Adam Liszkai <contact@liszkaiadam.hu>
 * @link	http://ionizecms.com
 * @since	Version 2.0.0
 */
class Api extends IO_Controller
{
	
}
/* End of file: Api.php */
/* Location: ./ionize/controllers/Api.php */
