<?php


$lang['ionize_presentation'] = 'Ionize is an Open Source PHP Content Management system created by webdesigners for webdesigners. With a powerful core and user-friendly backend, everybody can build easy to maintain websites. The new version has evolved new features, what will provide heavy support for developers.';

$lang['more_information'] = 'For more information about building a website with Ionize, you can:
							<ul>
								<li>Download & read the Documentation</li>
								<li>Visit the Community Forum</li>
							</ul>';
							
$lang['lets_start'] = 'Lets install the new version!';
