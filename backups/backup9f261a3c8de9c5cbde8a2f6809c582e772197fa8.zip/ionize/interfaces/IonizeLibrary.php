<?php

interface IonizeLibrary
{
	public function initialize( $data );
}
