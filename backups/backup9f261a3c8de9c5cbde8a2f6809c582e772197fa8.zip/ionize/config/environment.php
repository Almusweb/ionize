<?php


$config['force_models_namespace'] = FALSE;
$config['models_namespace'] = "\\Model";
